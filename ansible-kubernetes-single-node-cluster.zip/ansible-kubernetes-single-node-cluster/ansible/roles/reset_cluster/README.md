# Reset Cluster

Role to reset the Kubernetes cluster.