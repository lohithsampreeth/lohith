# K8s Cluster

Role to setup the EKS Cluster Master Node