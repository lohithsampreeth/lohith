# Install K8s

Role to install Kubernetes stuff.

<br/>

## Variables

| Variable name | Type | Value |
|---|---|---|
| **kube_packages** | List | - kubelet <br>  - kubeadm <br> - kubectl |
