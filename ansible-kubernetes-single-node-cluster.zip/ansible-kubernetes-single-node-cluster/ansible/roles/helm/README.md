# Helm

Role to set the Helm repository key and install it.