# Delete K8s

Role to remove and clean all Kubernetes stuff.
