# Install Docker

Role to set-up the repository and install Docker.