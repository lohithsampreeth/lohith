# Install Calico

Role to install Calico as the Network Interface for the Kubernetes Cluster.