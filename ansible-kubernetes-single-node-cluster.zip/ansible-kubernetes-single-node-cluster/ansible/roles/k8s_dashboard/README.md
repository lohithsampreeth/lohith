# K8s Dashboard

Role to set-up the Kubernetes Dashboard