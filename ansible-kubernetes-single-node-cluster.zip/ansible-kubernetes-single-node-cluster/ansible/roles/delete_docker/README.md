# Delete docker

Role to delete all the packages related to Docker.
